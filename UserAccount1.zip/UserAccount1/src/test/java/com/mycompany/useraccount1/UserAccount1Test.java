/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.useraccount1;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author anomp
 */
public class UserAccount1Test {
    
   

    // Test username validation
    @Test
    public void testValidUsername() {
        assertTrue(UserAccount1.checkUsername("ab_cd"));
    }

    @Test
    public void testInvalidUsername_NoUnderscore() {
        assertFalse(UserAccount1.checkUsername("abcd"));
    }

    @Test
    public void testInvalidUsername_TooLong() {
        assertFalse(UserAccount1.checkUsername("abc_de"));
    }

    // Test password validation
    @Test
    public void testValidPassword() {
        assertTrue(UserAccount1.checkPassword("Pass@123"));
    }

    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(UserAccount1.checkPassword("Password1"));
    }

    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(UserAccount1.checkPassword("P@1"));
    }

    // Test phone validation
    @Test
    public void testValidPhone() {
        assertTrue(UserAccount1.checkPhone("+27831234567"));
    }

    @Test
    public void testInvalidPhone() {
        assertFalse(UserAccount1.checkPhone("0831234567"));
    }

    // Test phone hiding
    @Test
    public void testHidePhone() {
        String result = UserAccount1.hidePhone("+27831234567");
        assertEquals("+27*********", result);
    }
}
    
    

